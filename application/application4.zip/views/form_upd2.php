<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Forms | Hers test</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/vendors/feather/feather.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/vendors/select2/select2.min.css">
  <link rel="stylesheet"
    href="<?php echo base_url(); ?>asset/vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>asset/images/favicon.png" />
  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
  <link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css"
  rel="stylesheet"
/>

</head>

<body>
  <div class="container-scroller">
    <!-- partial:<?php echo base_url(); ?>asset/partials/_navbar.html -->
    <?php include('header.php'); ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:<?php echo base_url(); ?>asset/partials/_settings-panel.html -->


      <!-- partial -->
      <!-- partial:<?php echo base_url(); ?>asset/partials/_sidebar.html -->
      <?php include('sidebar.php'); ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">


            <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">



                  <div class="row">
                    <div class="col-md-8">
                      <h4 class="card-title">HERS Test Update</h4>

                    </div>
                    <div class="col-4">
                    
                      <button type="button" class="btn btn-danger top-right-button float-right mr-1" data-toggle="modal"
                        data-target="#deleteModal">Delete</button>
                        <a href="#" target="_blank" class="btn btn-primary top-right-button float-right mr-1">Get PDF</a>
                        <!-- <?php echo base_url();?>PdfReport/hersReport/<?php ?> -->
                    </div>
                  </div>




                  <!-- Modal -->

                  <div id="deleteModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-body text-center">
                          <form method="post" action="<?php echo base_url(); ?>Form/delete/<?php  ?>">
                            <p>Are you Sure You want to Delete this item?</p>
                            <button type="submit" class="btn btn-danger">Delete</button>
                            <button type="button" class="btn btn-grey" data-dismiss="modal">Cancel</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>



                  <!-- Modal End -->
                  <?php
                  if( $this->session->flashdata('message_success') ) { ?>
                  <div class="row">
                    <div class="col-12 mt-4">
                      <div class="alert alert-success" role="alert">
                        <?php echo $this->session->flashdata('message_success'); ?>
                      </div>
                    </div>
                  </div>
                  <?php }
                  ?>


                  <?php
                    if( $this->session->flashdata('message_error') ) { ?>
                  <div class="row">
                    <div class="col-12 mt-4">
                      <div class="alert alert-danger" role="alert">
                        <?php echo $this->session->flashdata('message_error'); ?>
                      </div>
                    </div>
                  </div>
                  <?php }
                  ?>


                        
                            
                      

                    <div class="row" id="initialForm">

                            <div class="form-group d-none">
                              
                                <label>URL*</label>
                                <input type="text" class="form-control" name="url" placeholder="url " value="form">
                                form number
                                <input type="text" class="form-control" name="no_of_form" placeholder="forms Number" value="<?=$fs->no_of_form?>">
                                tech_id
                                <input type="text" class="form-control" name="tech_id" placeholder="tech_id " value="<?=$fs->tech_id?>">

                                <input type="text" class="form-control" name="id" placeholder="form_id" value="<?=$fs->id?>">

                            </div>

                            <?php $b = json_decode($fs->basic_info);?>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Test Name*</label>
                                    <input type="text" class="form-control" name="test_name" placeholder="Test Name"  readonly value="<?=$b->test_name?>">
                                </div>
                            </div><!-- col-md-6 End-->   

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Company Name*</label>
                                    <input type="text" class="form-control" name="company_name" placeholder="Company Name"  value="<?=$b->company_name?>">
                                </div>
                            </div><!-- col-md-6 End-->

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Site Address*</label>
                                    <input type="text" class="form-control" name="site_address" placeholder="Site Address"  value="<?=$b->site_address?>">
                                </div>
                            </div><!-- col-md-6 End offset-sm-1-->

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email*</label>
                                    <input type="text" class="form-control" name="email" placeholder="Email"  value="<?=$b->email?>">
                                </div>
                            </div><!-- col-md-6 End-->

      

                            <!-- <div class="col-md-12">
                                <button type="button" class="btn btn-primary mr-2" onclick="initialSubmit()">Next</button>
                                <button type="button" class="btn btn-light float-right" onclick="initialClear()">Clear Form</button>

                            </div> -->

                    </div>


                    

                    <?php// if($i != 0){ echo 'collapsed';}?>
                    <?php // if($i == 0){ echo 'show';}?>
                      <div class="accordion" id="accordionExample">

                      <?php 
                        for($i=0; $i<$fs->no_of_form ; $i++){
                        ?>

                       
                        <div class="accordion-item">
                          <h2 class="accordion-header" id="headingOne">
                            <button
                              class="accordion-button collapsed" 
                              type="button"
                              data-mdb-toggle="collapse"
                              data-mdb-target="#collapse<?=$i?>"
                              aria-expanded="true"
                              aria-controls="collapse<?=$i?>" onclick="accordionClick(<?=$i?>)" >
                             <strong>  Form Number: <?php echo $i+1 ?> </strong>
                            </button>
                          </h2>
                          <div id="collapse<?=$i?>" class="accordion-collapse collapse " aria-labelledby="headingOne" data-mdb-parent="#accordionExample">
                            <div class="accordion-body">
                              <div id="accordion_body<?=$i?>"></div>
                            </div>
                          </div>
                        </div>


                        <?php } ?>
                        
                      </div>


                    
                

                    

                        

                </div>
              </div>
            </div>



          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:<?php echo base_url(); ?>asset/partials/_footer.html -->
        <?php include('footer.php');?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <div></div>
  <script src="<?php echo base_url(); ?>asset/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo base_url(); ?>asset/vendors/typeahead.js/typeahead.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/vendors/select2/select2.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo base_url(); ?>asset/js/off-canvas.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/hoverable-collapse.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/template.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/settings.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url(); ?>asset/js/file-upload.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/typeahead.js"></script>
  <script src="<?php echo base_url(); ?>asset/js/select2.js"></script>


  <script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.js"
></script>
  <!-- jQuery library -->
<!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script> -->

<!-- Popper JS -->
<!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> -->

<!-- Latest compiled JavaScript -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script> -->

  <!-- End custom js for this page-->

<?php 
 include('layout_upd/package_unit.php');
 include('layout_upd/central_split.php');
 include('layout_upd/heat_pump.php');
 include('layout_upd/ductless_unit.php');

?>
  
  <script>
    fs = [];
    fs[0] = <?=(is_null($fs->form_1))? 'null' :  $fs->form_1;?>;
    fs[1] = <?=(is_null($fs->form_2))? 'null' :  $fs->form_2;?>;
    fs[2] = <?=(is_null($fs->form_3))? 'null' :  $fs->form_3;?>;
    fs[3] = <?=(is_null($fs->form_4))? 'null' :  $fs->form_4;?>;
    fs[4] = <?=(is_null($fs->form_5))? 'null' :  $fs->form_5;?>;
    fs[5] = <?=(is_null($fs->form_6))? 'null' :  $fs->form_6;?>;
    fs[6] = <?=(is_null($fs->form_7))? 'null' :  $fs->form_7;?>;
    fs[7] = <?=(is_null($fs->form_8))? 'null' :  $fs->form_8;?>;
    fs[8] = <?=(is_null($fs->form_9))? 'null' :  $fs->form_9;?>;
    fs[9] = <?=(is_null($fs->form_10))? 'null' :  $fs->form_10;?>;
    fs[10] = <?=(is_null($fs->form_11))? 'null' :  $fs->form_11;?>;
    fs[11] = <?=(is_null($fs->form_12))? 'null' :  $fs->form_12;?>;
    fs[12] = <?=(is_null($fs->form_13))? 'null' :  $fs->form_13;?>;
    fs[13] = <?=(is_null($fs->form_14))? 'null' :  $fs->form_14;?>;
    fs[14] = <?=(is_null($fs->form_15))? 'null' :  $fs->form_15;?>;
    fs[15] = <?=(is_null($fs->form_16))? 'null' :  $fs->form_16;?>;
    fs[16] = <?=(is_null($fs->form_17))? 'null' :  $fs->form_17;?>;
    fs[17] = <?=(is_null($fs->form_18))? 'null' :  $fs->form_18;?>;
    fs[18] = <?=(is_null($fs->form_19))? 'null' :  $fs->form_19;?>;
    fs[19] = <?=(is_null($fs->form_20))? 'null' :  $fs->form_20;?>;
    console.log(fs);




    function accordionClick(param){
     
      unit_type = fs[param]['unit_type'];

      $('div[id^="accordion_body"]').filter(
      function(){
        $(this).html('');
      });

      if(unit_type == "Package Unit"){
        $(`#accordion_body${param}`).html(package_unit);
        packageUnitFill(param);
      } else if(unit_type == "Central Split AC"){
        $(`#accordion_body${param}`).html(central_split);

        centralGasFill(param);
      } else if (unit_type == "Heat Pump"){
        $(`#accordion_body${param}`).html(heat_pump);
      }else if (unit_type == "Ductless Unit"){
        $(`#accordion_body${param}`).html(ductless_unit);
      }

    }

    function packageUnitFill(param){
      var pu_manufacturer = JSON.parse(fs[param]['pu_manufacturer']);
      for(i=0 ; i<pu_manufacturer.length;i++){
        if(i!=0){ packageUnit_addMore(); }

        $("input[name='pu_manufacturer[]']:eq("+i+")").val(pu_manufacturer[i]);
      }
    }


    function centralGasFill(param){
        
        // for(i=0; i<)
        
    }

  //   $('.accordion-button').click(function(){
  //     console.log("this one");
	// 	var index=$(this).data('mdb-target');
  //   console.log("index", index);
	// 	// if (accordion.accordion( "option", "active")===index){
	// 	// 	accordion.accordion( "option", "active", false )
	// 	// } else
	// 	// 	accordion.accordion( "option", "active", index )
	// 	// return false;
	// })
  </script>

  <?php
  include('layout_upd/form_script.php');
  ?>
</body>

</html>